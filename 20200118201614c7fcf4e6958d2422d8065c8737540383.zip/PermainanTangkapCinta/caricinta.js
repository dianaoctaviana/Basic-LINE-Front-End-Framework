var canvas = document.createElement("canvas");
var ctx = canvas.getContext("2d");
canvas.width = 512;
canvas.height = 512;
document.body.appendChild(canvas);

var bgReady = false;
var bgImage = new Image();
bgImage.onload = function () {
	bgReady = true;
};
bgImage.src = "lapangan.jpg";
var ceweReady = false;
var gambarCewe = new Image();
gambarCewe.onload = function () {
	ceweReady = true;
};
gambarCewe.src = "iconcewe.png";
var loveReady = false;
var gambarLove = new Image();
gambarLove.onload = function () {
	loveReady = true;
};
gambarLove.src = "iconlove2.png";
var cewe = {
	speed: 256 };
var love = {};
var tangkapCinta = 0;

var keyControl = {};

addEventListener("keydown", function (e) {
	keyControl[e.keyCode] = true;
}, false);

addEventListener("keyup", function (e) {
	delete keyControl[e.keyCode];
}, false);


var reset = function () {
	cewe.x = canvas.width / 2;
	cewe.y = canvas.height / 2;

	love.x = 32 + (Math.random() * (canvas.width - 64));
	love.y = 32 + (Math.random() * (canvas.height - 64));
};

var update = function (modifier) {
	if (38 in keyControl) { 
		cewe.y -= cewe.speed * modifier;
	}
	if (40 in keyControl) { 
		cewe.y += cewe.speed * modifier;
	}
	if (37 in keyControl) { 
		cewe.x -= cewe.speed * modifier;
	}
	if (39 in keyControl) { 
		cewe.x += cewe.speed * modifier;
	}

	if (
		cewe.x <= (love.x + 32)
		&& love.x <= (cewe.x + 32)
		&& cewe.y <= (love.y + 32)
		&& love.y <= (cewe.y + 32)
	) {
		++tangkapCinta;
		reset();
	}
};

var render = function () {
	if (bgReady) {
		ctx.drawImage(bgImage, 0, 0);
	}

	if (ceweReady) {
		ctx.drawImage(gambarCewe, cewe.x, cewe.y);
	}

	if (loveReady) {
		ctx.drawImage(gambarLove, love.x, love.y);
	}

	ctx.fillStyle = "rgb(0, 0, 0)";
	ctx.font = "20px Times New Roman";
	ctx.textAlign = "left";
	ctx.textBaseline = "top";
	ctx.fillText("Jumlah Cinta: " + tangkapCinta, 32, 32);
};

var main = function () {
	var now = Date.now();
	var delta = now - then;

	update(delta / 1000);
	render();

	then = now;

	requestAnimationFrame(main);
};

var w = window;
requestAnimationFrame = w.requestAnimationFrame || w.webkitRequestAnimationFrame || w.msRequestAnimationFrame || w.mozRequestAnimationFrame;

var then = Date.now();
reset();
main();
